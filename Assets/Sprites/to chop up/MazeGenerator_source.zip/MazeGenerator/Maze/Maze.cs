using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Maze : MonoBehaviour
{
	#region Fields
	
	/// <summary>
	/// True if the maze should wrap across borders.
	/// </summary>
	public bool Wrap = false;
	
	/// <summary>
	/// The random seed.
	/// </summary>
	public int Seed = 3141592;
	
	/// <summary>
	/// The width of the maze grid.
	/// </summary>
	public int Width = 32;
	
	/// <summary>
	/// The height of the maze grid.
	/// </summary>
	public int Height = 32;
	
	/// <summary>
	/// The initial position to begin maze construction.
	/// </summary>
	public Vector2 InitialPosition = Vector2.zero;
	
	/// <summary>
	/// The maze grid.
	/// </summary>
	private Grid<MazeCell> MazeGrid;
	
	#endregion
	
	#region Methods
	
	/// <summary>
	/// Local initialization.
	/// </summary>
	private void Awake()
	{
		MazeGrid = GenerateMaze();
		
		if (Debug.isDebugBuild)
			GenerateDebug();
	}
	
	/// <summary>
	/// Generates a maze to use as a basis for the map.
	/// </summary>
	private Grid<MazeCell> GenerateMaze()
	{	
		// Initialize variables
		Random.seed = Seed;
		Stack<GridLocation> cellsVisited = new Stack<GridLocation>();
		Grid<MazeCell> grid = new Grid<MazeCell>(Width, Height);
		int crawlDistance = 0;
		int maxCrawlDistance = 0;
		
		// Select initial cell position, flag it as the initial cell,
		// and push it onto the stack.
		GridLocation cellPos = grid.WrapCoordinates((int)InitialPosition.x, (int)InitialPosition.y);
		grid.GetCellAt(cellPos).IsStartCell = true;
		cellsVisited.Push(cellPos);
		
		// Recursively crawl the maze.
		while (cellsVisited.Count > 0)
		{	
			// Flag the cell as visited.
			MazeCell cell = grid.GetCellAt(cellPos);
			cell.Flagged = true;
			cell.CrawlDistance = crawlDistance;
			
			// Calculate valid exits from the current cell position.
			MazeCellExits validExits = MazeCellExits.None;
			if ((Wrap || cellPos.x != 0)			&& !grid.GetCellAt(cellPos.x - 1, cellPos.y).Flagged) { validExits = validExits | MazeCellExits.West; }
			if ((Wrap || cellPos.x != Width - 1) 	&& !grid.GetCellAt(cellPos.x + 1, cellPos.y).Flagged) { validExits = validExits | MazeCellExits.East; }
			if ((Wrap || cellPos.y != 0) 			&& !grid.GetCellAt(cellPos.x, cellPos.y - 1).Flagged) { validExits = validExits | MazeCellExits.North; }
			if ((Wrap || cellPos.y != Height - 1)	&& !grid.GetCellAt(cellPos.x, cellPos.y + 1).Flagged) { validExits = validExits | MazeCellExits.South; }
			
			// When valid exits are found, flag the tile with a random
			// exit and select the next tile. Otherwise backtrack through the
			// stack looking for the most recently visited tile with valid
			// exits.
			if (validExits != MazeCellExits.None)
			{
				// Increment crawlDistance
				crawlDistance++;
				
				// Add the cell to the stack so we can return to it later for
				// recursive exit checking.
				cellsVisited.Push(cellPos);
				
				// Choose a random exit from the available exits.
				MazeCellExits exit = GetRandomExit(validExits);
				cell.Exits = cell.Exits | exit;
				
				// Select the next tile.
				if (exit == MazeCellExits.North)
				{
					cellPos = new GridLocation(cellPos.x, cellPos.y - 1);
					exit = MazeCellExits.South;
				}
				else if (exit == MazeCellExits.South)
				{
					cellPos = new GridLocation(cellPos.x, cellPos.y + 1);
					exit = MazeCellExits.North;
				}
				else if (exit == MazeCellExits.West)
				{
					cellPos = new GridLocation(cellPos.x - 1, cellPos.y);
					exit = MazeCellExits.East;
				}
				else if (exit == MazeCellExits.East)
				{
					cellPos = new GridLocation(cellPos.x + 1, cellPos.y);
					exit = MazeCellExits.West;
				}
				
				// Create an exit back to the previous tile.
				cell = grid.GetCellAt(cellPos);
				cell.Exits = cell.Exits | exit;
			}
			else
			{
				// Update max crawl distance.
				if (maxCrawlDistance < crawlDistance)
					maxCrawlDistance = crawlDistance;
				// Decrement crawlDistance
				crawlDistance--;
				
				if (cell.NumberOfExits == 1)
					cell.IsDeadEnd = true;
				
				// No valid exits so backtrack through the stack.
				cellPos = cellsVisited.Pop();
			}
		}
		
		foreach (MazeCell cell in grid.CellArray)
			cell.NormalizedDistance = (float)cell.CrawlDistance / (float)maxCrawlDistance;
		
		return grid;
	}
	
	/// <summary>
	/// Gets a random cardinal direction from the specified directions.
	/// </summary>
	private MazeCellExits GetRandomExit(MazeCellExits validExits)
	{
		List<MazeCellExits> exits = new List<MazeCellExits>();
		if ((validExits & MazeCellExits.North) 	== MazeCellExits.North) exits.Add(MazeCellExits.North);
		if ((validExits & MazeCellExits.South) 	== MazeCellExits.South) exits.Add(MazeCellExits.South);
		if ((validExits & MazeCellExits.East) 	== MazeCellExits.East) 	exits.Add(MazeCellExits.East);
		if ((validExits & MazeCellExits.West) 	== MazeCellExits.West) 	exits.Add(MazeCellExits.West);
		
		int randIndex = (int)(Random.value * exits.Count);
		if (randIndex == exits.Count) randIndex--;
		
		return exits[randIndex];
	}
	
	/// <summary>
	/// Generates the debug render.
	/// </summary>
	private void GenerateDebug()
	{
		gameObject.AddComponent<DebugMazeCells>();
		DebugMazeCells debug = gameObject.GetComponent<DebugMazeCells>();
		foreach (MazeCell cell in MazeGrid.CellArray)
			debug.AddCell(cell);
	}
	
	#endregion
}